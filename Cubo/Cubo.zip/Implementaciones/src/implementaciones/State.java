
package implementaciones;

/**
 *
 * @author JuanFelipe
 */
public interface State {
    public boolean equals(State state);
}
